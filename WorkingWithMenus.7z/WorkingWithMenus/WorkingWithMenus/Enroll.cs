﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
namespace WorkingWithMenus
{
    public partial class Enroll : Form
    {
        public Enroll()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
           try
            {
               // if (textBoxName.Text.Length == 0 || textBoxPass.Text.Length == 0 || textBoxUser.Text.Length == 0 || textBoxPhone.Text.Length ==0 || comboBox1.Text.Length == 0)
               //{MessageBox.Show("Fields cant be left empty");
               //textBoxName.Focus();
               //return;
               //}
                if (!System.Text.RegularExpressions.Regex.IsMatch(textBoxName.Text, "^[a-zA-Z]"))
                            {
                                MessageBox.Show("Textbox accepts only alphabetic character");
                                textBoxName.Text.Remove(textBoxName.Text.Length - 1);
                                textBoxName.Focus();
                                return;
                            }

              
              
                if (!System.Text.RegularExpressions.Regex.IsMatch(textBoxUser.Text, "^[a-zA-Z]"))
                            {
                                MessageBox.Show("Textbox accepts only alphabetic character");
                                textBoxUser.Text.Remove(textBoxUser.Text.Length - 1);
                                textBoxUser.Focus();
                                return;
                            }
           
               int parsedvalue;
               if(!int.TryParse(textBoxPhone.Text,out parsedvalue))
                           {
                           
                               MessageBox.Show("Phone no must be in integer");
                               textBoxPhone.Focus();
                               return;
                           }
                     if(!int.TryParse(textBoxPass.Text,out parsedvalue))
                           {
                           
                               MessageBox.Show("Password  must be in integer");
                               textBoxPhone.Focus();
                               return;
                           }
                     bool validmail = IsValidEmail(textBoxEmail.Text);
                     if (validmail == false)
                                     {
                                         MessageBox.Show("Not a valid email address");
                                         textBoxEmail.Focus();
                                         return;
                                     }
                     else
                                     {
                                         MessageBox.Show("valid email address");
                                     }

                BAL.Class1 bl = new BAL.Class1();
                int returnvalue = bl.uspGetValidationData(textBoxName.Text, textBoxPhone.Text, textBoxUser.Text, textBoxPass.Text, comboBoxType.Text, textBoxEmail.Text);
                if (returnvalue == 1)
                                {
                                    MessageBox.Show("Insertion Successful");
                                    selection();
                                }
                else
                                {
                                    MessageBox.Show(textBoxName.Text + "\n" + textBoxPhone.Text + "\n" + textBoxUser.Text + "\n" + textBoxPass.Text);
                                    MessageBox.Show("Insertion unsuccessful");
                                    selection();
                                }
                }
           
            catch(Exception ex)
                               {
                                }
        }
           
               bool IsValidEmail(string email)
               {
                    try
                                    { var add = new MailAddress(email);
                                        
                                      return add.Address == email;
                                     }
                   catch
                                     {
                                       return false;
                                      }
               }
           
        public void selection()
        {
            string ConnectionString = "Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd";
            string selectCommand = "Select * from Library1";
            // Create a new data adapter based on the specified query.
            SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, ConnectionString);

            // Create a command builder to generate SQL update, insert, and
            // delete commands based on selectCommand. These are used to
            // update the database.
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

            // Populate a new data table and bind it to the BindingSource.
            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            dataAdapter.Fill(table);
            dataGridView1.DataSource = table;

        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
        }

    


        }
    }

