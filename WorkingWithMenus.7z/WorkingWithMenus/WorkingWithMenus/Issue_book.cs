﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace WorkingWithMenus
{
    public partial class Issue_book : Form
    {
        public Issue_book()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string issuedate;
            
            try{
                issuedate = DateTime.Now.ToString("dd-MM-yyyy HH:MM:SS");
                string expectedreturndate = DateTime.Today.AddDays(30).ToString("dd-MM-yyyy HH:MM:SS"); ;
                BAL.Class1 bl = new BAL.Class1();
                int returnvalue = bl.uspIssue(comboBoxStudentid.Text, comboBoxIssuebook.Text, issuedate, expectedreturndate);
                if (returnvalue == 1)
                                {
                                    MessageBox.Show("Insertion Successful");
                                    selection();
                                }
                else
                                {
                                    MessageBox.Show("Insertion unsuccessful");
                                    selection();
                                }

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
                MessageBox.Show("Server Not Available");

            }

        }

        public void selection()
        {
            string ConnectionString = "Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd";
            string selectCommand = "Select * from issue";
            // Create a new data adapter based on the specified query.
            SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, ConnectionString);

            // Create a command builder to generate SQL update, insert, and
            // delete commands based on selectCommand. These are used to
            // update the database.
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

            // Populate a new data table and bind it to the BindingSource.
            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            dataAdapter.Fill(table);
            dataGridView1.DataSource = table;

        }

    



        private void comboBoxStudentid_Click(object sender, EventArgs e)
        {
            
            comboBoxStudentid.Items.Clear();
            
                SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd");
            string Sql = "select name from dbo.Library1";
            conn.Open();
            SqlCommand cmd = new SqlCommand(Sql, conn);
            SqlDataReader DR = cmd.ExecuteReader();

            while (DR.Read())
            {
                comboBoxStudentid.Items.Add(DR[0]);
               

            }
        }

       
        private void comboBoxIssuebook_Click(object sender, EventArgs e)
        {
            
                //comboBoxIssuebook.Items.Clear();

                SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd");
                string query = "select name,id from dbo.Book";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                conn.Open();
                DataSet ds = new DataSet();
                da.Fill(ds, "Book");
                comboBoxIssuebook.DisplayMember = "name";
                comboBoxIssuebook.ValueMember = "id";
                comboBoxIssuebook.DataSource = ds.Tables["Book"];

            }
          


        }

     
        }
      

   

