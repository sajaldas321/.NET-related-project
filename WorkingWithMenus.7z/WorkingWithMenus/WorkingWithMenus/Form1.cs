﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WorkingWithMenus
{
    public partial class Master : Form
    {
        public Master()
        {
            InitializeComponent();
        }

      

       
        private void viewCardDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Card_details child4 = new Card_details();
            child4.MdiParent = this;
            child4.Show();

        }

        private void addBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Issue_book child5 = new Issue_book();
            child5.MdiParent = this;
            child5.Show();
        }

        private void boToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_book child6 = new Add_book();
            child6.MdiParent = this;
            child6.Show();

        }


        private void enrollToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Enroll child4 = new Enroll();
            child4.MdiParent = this;
            child4.Show();
        }

        private void returnBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Return child5 = new Return();
            child5.MdiParent = this;
            child5.Show();
        }

      


        
  
    }
}
