﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace WorkingWithMenus
{
    public partial class Return : Form
    {
        public Return()
        {
            InitializeComponent();
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {

            //comboBox1.Items.Clear();

            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd");
            string Sql = "select name,id from dbo.Library1";
            conn.Open();
            SqlDataAdapter da1 = new SqlDataAdapter(Sql, conn);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1, "Library1");
            comboBox1.DisplayMember = "name";
            comboBox1.ValueMember = "id";
            comboBox1.DataSource = ds1.Tables["Library1"];

            comboBox2.Visible=true;
}



        private void comboBox2_Click(object sender, EventArgs e)
        {
            try
            {
                //comboBoxIssuebook.Items.Clear();
                comboBox2.Focus();

                MessageBox.Show(comboBox1.Text.ToString());
                SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd");
                string query = "select name,id from dbo.Book where name=" + comboBox1.Text.ToString();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                conn.Open();
                DataSet ds = new DataSet();
                da.Fill(ds, "Book");
                comboBox2.DisplayMember = "name";
                comboBox2.ValueMember = "id";
                comboBox2.DataSource = ds.Tables["Book"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
                MessageBox.Show("Server Not Available");

            }

        }

      
        
    }
}
