﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WorkingWithMenus
{
    public partial class Add_book : Form
    {
        public Add_book()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            SqlConnection con=new SqlConnection();
            con.ConnectionString="Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd";
            con.Open();
            string query = "insert into Book(name,author,genre,available) values( '" + textBoxbooknama.Text + "','" + textBoxAuthor.Text + "','" + comboBoxGenre.Text + "','"+"available"+"'  )";
             
            SqlCommand cmd=new SqlCommand(query,con);
            cmd.ExecuteNonQuery();
             
            MessageBox.Show("Data Inserted in Database!");
            selection();
        }

        
        public void selection()
        {
            string ConnectionString = "Data Source=.;Initial Catalog=Library;Persist Security Info=True;User ID=sa;Password=pwd";
            string selectCommand = "Select * from Book";
            // Create a new data adapter based on the specified query.
            SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, ConnectionString);

            // Create a command builder to generate SQL update, insert, and
            // delete commands based on selectCommand. These are used to
            // update the database.
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

            // Populate a new data table and bind it to the BindingSource.
            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            dataAdapter.Fill(table);
            dataGridView1.DataSource = table;
        
        }

       
       
    }
}
