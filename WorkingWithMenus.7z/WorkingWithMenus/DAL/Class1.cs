﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace DAL
{
    public class Class1
    {
        public int uspGetValidationData(string sp, string con, string name, string phone, string user, string pass, string type, string email)
        {
            try
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = con;

                string spName = sp;
                OleDbCommand DASelectCommand = new OleDbCommand(spName, connection);
                DASelectCommand.CommandType = CommandType.StoredProcedure;
                DASelectCommand.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                DASelectCommand.Parameters.Add("@phone", SqlDbType.VarChar).Value = phone;
                DASelectCommand.Parameters.Add("@userid", SqlDbType.VarChar).Value = user;
                DASelectCommand.Parameters.Add("@pass", SqlDbType.VarChar).Value = pass;
                DASelectCommand.Parameters.Add("@membertype", SqlDbType.VarChar).Value = type;
                DASelectCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email;
                DASelectCommand.CommandTimeout = 0;
                connection.Open();
                DASelectCommand.ExecuteNonQuery();
                //END CODE FOR DISCONNECTED ARCHITECTURE

                return 1;
            }
            catch (Exception ex)
            {
                
                return 0;
            }
            //return 0;
        }

        public int uspIssue(string sp, string con, string studentid, string issue, string issuedate, string returndate)
        {
            try
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = con;

                string spName = sp;
                OleDbCommand DASelectCommand = new OleDbCommand(spName, connection);
                DASelectCommand.CommandType = CommandType.StoredProcedure;
                DASelectCommand.Parameters.Add("@member_id", SqlDbType.VarChar).Value = studentid;
                DASelectCommand.Parameters.Add("@book_id", SqlDbType.VarChar).Value = issue;
                DASelectCommand.Parameters.Add("@issue_date", SqlDbType.VarChar).Value = issuedate;
                DASelectCommand.Parameters.Add("@expected_return_date", SqlDbType.VarChar).Value = returndate;
                DASelectCommand.CommandTimeout = 0;
                connection.Open();
                DASelectCommand.ExecuteNonQuery();
                //END CODE FOR DISCONNECTED ARCHITECTURE

                return 1;
            }
            catch (Exception ex)
            {

                return 0;
            }
            //return 0;
        }





    }
}