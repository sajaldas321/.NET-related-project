﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BAL
{
    public class Class1
    {
        public int uspGetValidationData(string name, string phone,string user, string pass,string type,string email)
        {
            try
            {
                //string con = System.Configuration.ConfigurationSettings.AppSettings["SqlServerDatabasePath"];

                string con = "Provider=SQLOLEDB.1;Data Source=.;Password=pwd;User ID=sa;Initial Catalog=Library";
                DAL.Class1 dl = new DAL.Class1();
                string sp = "dbo.usp_enroll";
                
                int returnvaluee = dl.uspGetValidationData(sp , con , name , phone , user , pass,type,email);

                return returnvaluee;

            }
            catch (Exception ex)
            {
                return 0;
            }

        }
        public int uspIssue(string studentid, string issue, string issuedate,string returndate)
        {
            try
            {
                //string con = System.Configuration.ConfigurationSettings.AppSettings["SqlServerDatabasePath"];

                string con = "Provider=SQLOLEDB.1;Data Source=.;Password=pwd;User ID=sa;Initial Catalog=Library";
                DAL.Class1 dl = new DAL.Class1();
                string sp = "dbo.usp_issue";

                int returnvaluee = dl.uspIssue(sp, con, studentid, issue, issuedate, returndate);

                return returnvaluee;

            }
            catch (Exception ex)
            {
                return 0;
            }
        
        }




    }
}
